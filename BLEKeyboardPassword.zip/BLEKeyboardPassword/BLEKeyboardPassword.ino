#include <Arduino.h>
#include <Wire.h>
#include <KeyboardBLE.h>

// --- MCP23017 ve I2C Ayarları ---
#define MCP_ADDR     0x20
#define I2C_SDA_PIN  6
#define I2C_SCL_PIN  7

#define IODIRA       0x00
#define IODIRB       0x01
#define GPPUA        0x0C
#define GPPUB        0x0D
#define GPIOA_REG    0x12

// --- F13 - F24 HID Tuş Kodları ---
#ifndef KEY_F13
#define KEY_F13 (0xF0)
#define KEY_F14 (0xF1)
#define KEY_F15 (0xF2)
#define KEY_F16 (0xF3)
#define KEY_F17 (0xF4)
#define KEY_F18 (0xF5)
#define KEY_F19 (0xF6)
#define KEY_F20 (0xF7)
#define KEY_F21 (0xF8)
#define KEY_F22 (0xF9)
#define KEY_F23 (0xFA)
#define KEY_F24 (0xFB)
#endif

enum ActionType {
  TYPE_KEY,      // Tek tuş (F13..F24)
  TYPE_SHORTCUT  // Kısayol (Ctrl+C, Ctrl+V vb.)
};

struct MacroButton {
  ActionType type;
  uint8_t key;
  uint8_t modifier;
};

// 16 Butonun Eşleme Tablosu
const MacroButton buttons[16] = {
  { TYPE_KEY,      KEY_F13, 0 },             // Buton 1  (GPA0) -> F13
  { TYPE_KEY,      KEY_F14, 0 },             // Buton 2  (GPA1) -> F14
  { TYPE_KEY,      KEY_F15, 0 },             // Buton 3  (GPA2) -> F15
  { TYPE_KEY,      KEY_F16, 0 },             // Buton 4  (GPA3) -> F16
  { TYPE_KEY,      KEY_F17, 0 },             // Buton 5  (GPA4) -> F17
  { TYPE_KEY,      KEY_F18, 0 },             // Buton 6  (GPA5) -> F18
  { TYPE_KEY,      KEY_F19, 0 },             // Buton 7  (GPA6) -> F19
  { TYPE_KEY,      KEY_F20, 0 },             // Buton 8  (GPA7) -> F20
  { TYPE_KEY,      KEY_F21, 0 },             // Buton 9  (GPB0) -> F21
  { TYPE_KEY,      KEY_F22, 0 },             // Buton 10 (GPB1) -> F22
  { TYPE_KEY,      KEY_F23, 0 },             // Buton 11 (GPB2) -> F23
  { TYPE_KEY,      KEY_F24, 0 },             // Buton 12 (GPB3) -> F24
  { TYPE_SHORTCUT, 'c',     KEY_LEFT_CTRL }, // Buton 13 (GPB4) -> Ctrl + C
  { TYPE_SHORTCUT, 'v',     KEY_LEFT_CTRL }, // Buton 14 (GPB5) -> Ctrl + V
  { TYPE_SHORTCUT, 'z',     KEY_LEFT_CTRL }, // Buton 15 (GPB6) -> Ctrl + Z
  { TYPE_SHORTCUT, 's',     KEY_LEFT_CTRL }  // Buton 16 (GPB7) -> Ctrl + S
};

// Debounce ve Durum Takibi
bool rawLastReading[16]    = {false};
bool debouncedState[16]    = {false};
unsigned long lastDebounceTime[16] = {0};
const unsigned long DEBOUNCE_DELAY = 40;

void writeMCP(uint8_t reg, uint8_t val) {
  Wire1.beginTransmission(MCP_ADDR);
  Wire1.write(reg);
  Wire1.write(val);
  Wire1.endTransmission();
}

uint16_t readMCPStable() {
  for (int retry = 0; retry < 3; retry++) {
    Wire1.beginTransmission(MCP_ADDR);
    Wire1.write(GPIOA_REG);
    if (Wire1.endTransmission() == 0) {
      if (Wire1.requestFrom(MCP_ADDR, 2) == 2) {
        uint8_t a = Wire1.read();
        uint8_t b = Wire1.read();
        return ((uint16_t)b << 8) | a;
      }
    }
    delayMicroseconds(200);
  }
  return 0xFFFF;
}

// Windows BLE için garantili zamanlamalı kısayol darbesi (Pulse)
void sendShortcut(uint8_t modifier, uint8_t key) {
  KeyboardBLE.press(modifier);
  delay(40); // BLE paketinin Windows tarafından yakalanması için bekleme
  KeyboardBLE.press(key);
  delay(70);
  KeyboardBLE.release(key);
  delay(20);
  KeyboardBLE.release(modifier);
  KeyboardBLE.releaseAll(); // Hiçbir tuş basılı kalmasın
}

void onButtonPress(int idx) {
  MacroButton b = buttons[idx];
  Serial.printf("[TUS BASILDI] Buton %2d\n", idx + 1);

  if (b.type == TYPE_SHORTCUT) {
    sendShortcut(b.modifier, b.key);
  } 
  else if (b.type == TYPE_KEY) {
    KeyboardBLE.press(b.key);
  }
}

void onButtonRelease(int idx) {
  MacroButton b = buttons[idx];
  if (b.type == TYPE_KEY) {
    KeyboardBLE.release(b.key);
  }
  KeyboardBLE.releaseAll();
}

void setup() {
  Serial.begin(115200);

  // 1. I2C Başlatma
  Wire1.setSDA(I2C_SDA_PIN);
  Wire1.setSCL(I2C_SCL_PIN);
  Wire1.begin();
  Wire1.setClock(50000);

  // MCP23017 Konfigürasyonu
  writeMCP(IODIRA, 0xFF);
  writeMCP(IODIRB, 0xFF);
  writeMCP(GPPUA,  0xFF);
  writeMCP(GPPUB,  0xFF);

  // 2. BLE Klavye Başlatma
  KeyboardBLE.begin();
  delay(100);
  KeyboardBLE.releaseAll();

  Serial.println("Pico 2 W BLE Macro Pad Hazir!");
}

void loop() {
  // BOOTSEL Butonu Testi
  if (BOOTSEL) {
    KeyboardBLE.print("ThisPasswordIsWeakLikeABaby");
    KeyboardBLE.setBattery(random(50, 100));
    while (BOOTSEL) delay(10);
    KeyboardBLE.releaseAll();
  }

  // 16 Buton Okuma
  uint16_t currentInputs = readMCPStable();

  if (currentInputs != 0xFFFF) {
    unsigned long now = millis();

    for (int i = 0; i < 16; i++) {
      bool reading = ((currentInputs & (1 << i)) == 0); // LOW = Basılı

      if (reading != rawLastReading[i]) {
        lastDebounceTime[i] = now;
        rawLastReading[i] = reading;
      }

      if ((now - lastDebounceTime[i]) > DEBOUNCE_DELAY) {
        if (reading != debouncedState[i]) {
          debouncedState[i] = reading;

          if (debouncedState[i] == true) {
            onButtonPress(i);
          } else {
            onButtonRelease(i);
          }
        }
      }
    }
  }

  delay(5);
}